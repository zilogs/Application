/**************************************************************************
  Fail when the cursor line is not in a block, or wordright reaches eof.
 **************************************************************************/
integer proc NextWordInBlock()
    while WordRight() and isCurrLineInBlock()
        if isCursorInBlock()
            return (TRUE)
        endif
    endwhile
    return (FALSE)
end

proc main()
    integer block_type = isCursorInBlock()

    if block_type
        PushBlock()
        PushPosition()
        GotoBlockBegin()
        GotoBlockBeginCol()
        Lower()

        repeat
            // temporarilay remove the block so we can uppercase the first letter
            PushBlock()
            UnmarkBlock()
            Upper()
            PopBlock()
        until not NextWordInBlock()

        PopPosition()
        PopBlock()
    endif
end

