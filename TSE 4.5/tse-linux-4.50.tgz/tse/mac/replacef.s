/*************************************************************************
  ReplaceF    Reload or replace the current file

  Author:     SemWare

  Overview:

  This macro simply calls the internal ReplaceFile() command to allow
  you to reload the current file (or replace it with another file).

  Keys:     (none)

  Change log:

  August, 1995 - Initial version
  24 Jan 2007  - SEM - save/restore the position

*************************************************************************/

proc main()
    integer line, row, column, xoffset

    line    = CurrLine()
    row     = CurrRow()
    column  = CurrCol()
    xoffset = CurrXOffset()
    if ReplaceFile()
        GotoLine(line)
        GotoRow(row)
        GotoColumn(column)
        GotoXOffset(xoffset)
    endif
end
