/****************************************************************************\

    TFECompB.S

    Start file comparison in batch mode

    Version         v2.10/03.08.95
    Copyright       (c) 1994,95 by DiK

    History

    v2.10/03.08.95  adaption to v2.5 of TSE

\****************************************************************************/

proc main()
    string cmd[254]

    if SplitPath(CurrFilename(),_NAME_|_EXT_) == "$______$.$_$"
        AbandonFile()
        cmd = CurrFilename()
        NextFile()
        cmd = "TSEComp " + CurrFilename() + " " + cmd
        ExecMacro(cmd)
        if NumFiles() == 0
            AbandonEditor()
        endif
    else
        Alarm()
        Warn("TSECompB can only be executed by TSEComp.BAT")
    endif
    PurgeMacro(CurrMacroFilename())
end

