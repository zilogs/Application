////////////////////////////
// jigvfr.s - a simplest virtual file ring jig
// Larry Hayes Smith
 proc mfiles(integer f)
 string fe[100]=""
case f
  when 0
    fe=splitpath(currfilename(),_ext_)
    repeat
      prevfile(_dontload_)
    until fe==splitpath(currfilename(),_ext_)
  when 1
    fe=splitpath(currfilename(),_ext_)
    repeat
      nextfile(_dontload_)
    until fe==splitpath(currfilename(),_ext_)
endcase
end

proc mrings(integer f)
 string fe[100]=""
 integer i=0
case f
  when 0
    fe=splitpath(currfilename(),_ext_)
    repeat
      prevfile(_dontload_)
      i=i+1
    until fe<>splitpath(currfilename(),_ext_)
          or i==numfiles()
  when 1
    fe=splitpath(currfilename(),_ext_)
    repeat
      nextfile(_dontload_)
      i=i+1
    until fe<>splitpath(currfilename(),_ext_)
          or i==numfiles()
endcase
end

proc main()
end

<ctrlshift LeftBtn> mfiles(0)
<ctrlshift RightBtn> mfiles(1)
<altshift LeftBtn> mrings(0)
<altshift RightBtn> mrings(1)
