/*************************************************************************
  DelToBol    Delete text from cursor to beginning of current line

  Author:     Ray Asbury

  Date:       Apr 23, 1993 - Initial version

  Overview:

  This macro is the complement to the DelToEol() command.  All text
  from the beginning of the line through the position preceding the
  cursor will be deleted.

  Keys:       (none)

  Usage notes:

  This macro does not have any key assignments.  To use, simply select
  it from the Potpourri menu.

*************************************************************************/

proc Main()
    while CurrCol() <> 1    // while not at beginning of line...
        BackSpace()         // delete the character to the left
    endwhile
end

